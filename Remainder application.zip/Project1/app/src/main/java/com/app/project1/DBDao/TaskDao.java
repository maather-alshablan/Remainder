package com.app.project1.DBDao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.app.project1.Modle.Tasks;

import java.util.List;

// استعلامات من الجداول الموجودة في الداتا بيس
@Dao
public interface TaskDao {

    // اضافة مهمة جديدة في الداتا بيس
    @Insert(entity = Tasks.class, onConflict = OnConflictStrategy.REPLACE)
    long addNewTasks(Tasks tasks);

    // جملة استعلام لعرض المهمات من الداتا بيس
    @Query("SELECT DISTINCT * FROM tasks")
    List<Tasks> getAllTasks();

    // جملة استعلام عشان افحص اذا التاريخ و الوقت موجود او لا
    @Query("SELECT DISTINCT * FROM tasks WHERE date = :date AND time =:time")
    List<Tasks> getAllTasksTime(String date, String time);

}
