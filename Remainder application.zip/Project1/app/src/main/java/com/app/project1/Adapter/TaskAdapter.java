package com.app.project1.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.app.project1.Modle.Tasks;
import com.app.project1.R;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.MyViewHolder> {
    private Context context;
    private List<Tasks> objects;


    public TaskAdapter(Context context, List<Tasks> objects) {
        this.context = context;
        this.objects = objects;
    }

    // تعريف اي item اعطيتو لل RecyclerView
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_task, viewGroup, false);
        return new MyViewHolder(view);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {

        // عرض القيم الموجودة ف ال object
        Tasks data = objects.get(i);

        myViewHolder.tv_name_task.setText(data.getName_task());
        myViewHolder.tv_level.setText(data.getLevel());
        myViewHolder.tv_date.setText(data.getDate());
        myViewHolder.tv_time.setText(data.getTime());


    }

    @Override
    public int getItemCount() {
        return objects.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        // اقدر اوصل للعناصر و اتحكم فيها
        TextView tv_name_task , tv_level , tv_date , tv_time;
        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_name_task = itemView.findViewById(R.id.tv_name_task);
            tv_level = itemView.findViewById(R.id.tv_level);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_time = itemView.findViewById(R.id.tv_time);

        }
    }
}
