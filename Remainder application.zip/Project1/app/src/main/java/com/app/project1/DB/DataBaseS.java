package com.app.project1.DB;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.app.project1.DBDao.TaskDao;
import com.app.project1.Modle.Tasks;

// تعريف الجداول الموجودة في الداتا بيس
@Database(entities = {Tasks.class}, version = 1, exportSchema = false)
public abstract class DataBaseS extends RoomDatabase {
    public static final String DATABASE_NAME = "tasks_db";
    private static DataBaseS instance;

    public static DataBaseS getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    DataBaseS.class,
                    DATABASE_NAME)
                    .allowMainThreadQueries().build();
        }
        return instance;
    }


    // ل اقدر اوصل الي جدول المهام و الاستعلامات الخاصة فيها
    public abstract TaskDao getTaskDao();


}
