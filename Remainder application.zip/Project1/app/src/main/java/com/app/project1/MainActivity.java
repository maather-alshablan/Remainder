package com.app.project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.app.project1.Adapter.TaskAdapter;
import com.app.project1.DB.DataBaseS;
import com.app.project1.Modle.Tasks;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btn_add;
    private RecyclerView rv_task;
    private EditText ed_name_task;
    private TextView tv_date_home, tv_time;
    private RadioButton rb_high, rb_low;

    private List<Tasks> tasks;
    private List<Tasks> tasks2;
    private DataBaseS database;
    private TaskAdapter taskAdapter;
    private String Level = "High";
    int hour, minute;

    Date date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findView();

        setUpAdapter();

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:m", Locale.getDefault()).format(new Date());


        Log.e("currentDate", "" + currentDate);
        Log.e("currentDate", "" + currentTime);

        tasks2 = database.getTaskDao().getAllTasksTime(currentDate, currentTime);


//        sendNotification("Test", "Low", "20/20/2002", "25:20");

        for (int i = 0; i < tasks2.size(); i++) {
            sendNotification(database.getTaskDao().getAllTasksTime(currentDate, currentTime).get(i).getName_task() ,database.getTaskDao().getAllTasksTime(currentDate, currentTime).get(i).getLevel() , database.getTaskDao().getAllTasksTime(currentDate, currentTime).get(i).getDate(), database.getTaskDao().getAllTasksTime(currentDate, currentTime).get(i).getTime());
        }


    }

    private void findView() {

        database = DataBaseS.getInstance(this);

        tasks = new ArrayList<>();
        tasks2 = new ArrayList<>();


        btn_add = findViewById(R.id.btn_add);
        ed_name_task = findViewById(R.id.ed_name_task);
        tv_date_home = findViewById(R.id.tv_date_home);
        tv_time = findViewById(R.id.tv_time);
        rb_high = findViewById(R.id.rb_high);
        rb_low = findViewById(R.id.rb_low);
        rv_task = findViewById(R.id.rv_task);


        btn_add.setOnClickListener(this);
        tv_date_home.setOnClickListener(this);
        tv_time.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_add:
                if (validation()) {

                    String name_task = ed_name_task.getText().toString();
                    String date = tv_date_home.getText().toString();
                    String time = tv_time.getText().toString();


                    if (rb_high.isChecked()) {
                        Level = "High";

                    } else if (rb_low.isChecked()) {
                        Level = "Low";

                    }

                    long a = database.getTaskDao().addNewTasks(new Tasks(name_task, Level, date, time));

                    if (a > 0) {

                        ed_name_task.setText("");
                        rb_high.setChecked(true);
                        tv_date_home.setText("Choose A Date");
                        tv_time.setText("Choose The Time");
                        Toast.makeText(this, "The Task Was Added Successfully", Toast.LENGTH_SHORT).show();
                        setUpAdapter();
                    }

                }
                break;


            case R.id.tv_date_home:
                showCalendarDialog();
                break;


            case R.id.tv_time:
                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, R.style.datepicker, (timePicker, i, i1) -> {
                    tv_time.setText(i + ":" + i1);
                }, hour, minute, true);
                timePickerDialog.show();
                break;
        }
    }

    private void setUpAdapter() {

        // عرض كافة المهام
        tasks = database.getTaskDao().getAllTasks();
        rv_task.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        taskAdapter = new TaskAdapter(MainActivity.this, tasks);
        rv_task.setAdapter(taskAdapter);
        taskAdapter.notifyDataSetChanged();


    }


    private void sendNotification(String name_task, String level, String date, String time) {
        Intent intent = new Intent(this, DetailsActivity.class);
        intent.putExtra("name_task", name_task);
        intent.putExtra("level", level);
        intent.putExtra("date", date);
        intent.putExtra("time", time);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, "general")
                .setSmallIcon(R.drawable.logo)
                .setContentTitle("Task Manager")
                .setContentText(name_task)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("general",
                    "pro",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify((int) (System.currentTimeMillis() / 1000), notificationBuilder.build());
    }


    private void showCalendarDialog() {
        final Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(Objects.requireNonNull(MainActivity.this), R.style.datepicker,
                (view, year, monthOfYear, dayOfMonth) -> {

                    c.setTimeInMillis(0);
                    c.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                    Date chosenDate = c.getTime();

                    tv_date_home.setText(formatToDisplayMessageFormat_2(chosenDate));


                }, mYear, mMonth, mDay);
        datePickerDialog.setTitle("");
        datePickerDialog.getDatePicker().setMinDate((System.currentTimeMillis() + 1 * 24 * 60 * 60 * 0000));
        datePickerDialog.show();
    }


    public static String formatToDisplayMessageFormat_2(Date date) {
        if (date == null) {
            return null;
        }
        String dateFormat = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        return simpleDateFormat.format(date);
    }


    // هذه الدالة تقوم بقحص جميع المدخلات اذا موجودة او لا

    private boolean validation() {

        if (!ValidationEmptyInput(ed_name_task)) {
            Toast.makeText(this, "The Name Of The Task is Empty", Toast.LENGTH_LONG).show();
            return false;

        } else if (tv_date_home.getText().toString().equals("Choose A Date")) {
            Toast.makeText(this, "Please Choose A Date", Toast.LENGTH_LONG).show();

            return false;

        } else if (tv_time.getText().toString().equals("Choose The Time")) {
            Toast.makeText(this, "Please Choose The Time", Toast.LENGTH_LONG).show();

            return false;

        } else {
            return true;

        }
    }


    // يتم من خلاها فحص ال edit اذا فاضي او لا
    public static boolean ValidationEmptyInput(EditText text) {
        if (TextUtils.isEmpty(text.getText().toString())) {
            return false;
        }
        return true;

    }
}
