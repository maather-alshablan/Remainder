package com.app.project1.Modle;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// جدول مهام
@Entity(tableName = "tasks")
public class Tasks {

    @PrimaryKey(autoGenerate = true)
    private int id ;
    private String name_task;
    private String level ;
    private String date ;
    private String time ;

    public Tasks() {
    }

    public Tasks(String name_task, String level, String date, String time) {
        this.name_task = name_task;
        this.level = level;
        this.date = date;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName_task() {
        return name_task;
    }

    public void setName_task(String name_task) {
        this.name_task = name_task;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
